/**
 * Placeholder for generated API client
 * This file will be replaced when running: npm run generate
 */

export class AcademyApi {
  constructor(_config?: any, _baseUrl?: string, _axiosInstance?: any) {}
  
  getAllStudents(_batchId?: number): Promise<any> { return Promise.resolve({ data: [] }) }
  getAllStudentsPaged(_page?: number, _size?: number, _sort?: string): Promise<any> { 
    return Promise.resolve({ data: { content: [], totalElements: 0, totalPages: 0, size: _size || 20, number: _page || 0, first: true, last: true } }) 
  }
  getStudentById(_id: number): Promise<any> { return Promise.resolve({ data: {} }) }
  createStudent(_student: any): Promise<any> { return Promise.resolve({ data: {} }) }
  updateStudent(_id: number, _student: any): Promise<any> { return Promise.resolve({ data: {} }) }
  deleteStudent(_id: number): Promise<any> { return Promise.resolve({}) }
  
  getAllBatches(_page?: number, _size?: number, _sort?: string): Promise<any> { 
    return Promise.resolve({ data: { content: [], totalElements: 0, totalPages: 0, size: _size ?? 20, number: _page ?? 0, first: true, last: true } }) 
  }
  getBatchById(_id: number): Promise<any> { return Promise.resolve({ data: {} }) }
  createBatch(_batch: any): Promise<any> { return Promise.resolve({ data: {} }) }
  updateBatch(_id: number, _batch: any): Promise<any> { return Promise.resolve({ data: {} }) }
  deleteBatch(_id: number): Promise<any> { return Promise.resolve({}) }
  assignClassToBatch(_id: number, _classId: number): Promise<any> { return Promise.resolve({ data: {} }) }
  
  getAllClasses(): Promise<any> { return Promise.resolve({ data: [] }) }
  getClassById(_id: number): Promise<any> { return Promise.resolve({ data: {} }) }
  createClass(_classData: any): Promise<any> { return Promise.resolve({ data: {} }) }
  updateClass(_id: number, _classData: any): Promise<any> { return Promise.resolve({ data: {} }) }
  deleteClass(_id: number): Promise<any> { return Promise.resolve({}) }
  
  getAllMentors(): Promise<any> { return Promise.resolve({ data: [] }) }
  getMentorById(_id: number): Promise<any> { return Promise.resolve({ data: {} }) }
  createMentor(_mentor: any): Promise<any> { return Promise.resolve({ data: {} }) }
  updateMentor(_id: number, _mentor: any): Promise<any> { return Promise.resolve({ data: {} }) }
  deleteMentor(_id: number): Promise<any> { return Promise.resolve({}) }
  
  getAllMentorSessions(): Promise<any> { return Promise.resolve({ data: [] }) }
  getMentorSessionById(_id: number): Promise<any> { return Promise.resolve({ data: {} }) }
  createMentorSession(_session: any): Promise<any> { return Promise.resolve({ data: {} }) }
  updateMentorSession(_id: number, _session: any): Promise<any> { return Promise.resolve({ data: {} }) }
  deleteMentorSession(_id: number): Promise<any> { return Promise.resolve({}) }
  
  login(_credentials: any): Promise<any> { return Promise.resolve({ data: { token: '', type: 'Bearer' } }) }
  validateToken(_request: any): Promise<any> { return Promise.resolve({ data: { valid: false } }) }
}

// Export placeholder types
export interface Student {
  id?: number
  name?: string
  email?: string
  graduationYear?: number
  universityName?: string
  phoneNumber?: string
  batchId?: number
  buddyId?: number
}

export interface StudentInput {
  name: string
  email: string
  graduationYear?: number
  universityName?: string
  phoneNumber?: string
  batchId?: number
  buddyId?: number
}

export interface PageStudent {
  content: Student[]
  totalElements: number
  totalPages: number
  size: number
  number: number
  first: boolean
  last: boolean
}

export interface Batch {
  id?: number
  name?: string
  startMonth?: string
  currentInstructor?: string
  batchTypeId?: number
  batchTypeName?: string
  classIds?: number[]
}

export interface BatchInput {
  name: string
  startMonth: string
  currentInstructor: string
  batchTypeId: number
  classIds?: number[]
}

export interface PageBatch {
  content: Batch[]
  totalElements: number
  totalPages: number
  size: number
  number: number
  first: boolean
  last: boolean
}

export interface ModelClass {
  id?: number
  name?: string
  date?: string
  time?: string
  instructor?: string
}

export interface ClassInput {
  name: string
  date: string
  time: string
  instructor: string
}

export interface Mentor {
  id?: number
  name?: string
  currentCompany?: string
}

export interface MentorInput {
  name: string
  currentCompany?: string
}

export interface MentorSession {
  id?: number
  time?: string
  durationMinutes?: number
  studentId?: number
  mentorId?: number
  studentRating?: number
  mentorRating?: number
}

export interface MentorSessionInput {
  time: string
  durationMinutes: number
  studentId: number
  mentorId: number
  studentRating?: number
  mentorRating?: number
}

export interface LoginRequest {
  username: string
  password: string
}

export interface AuthResponse {
  token: string
  type: string
}

export interface TokenValidationResponse {
  valid: boolean
  username?: string
  error?: string
}

