/**
 * @deprecated This file is kept for backward compatibility.
 * New code should use the generated API client from './generated-client'
 * which is generated from the OpenAPI specification.
 */
export { default as apiClient } from './generated-client'

